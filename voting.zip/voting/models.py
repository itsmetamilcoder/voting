from django.db import models

class Voter(models.Model):
    leadername = models.CharField(max_length=100)
    foundation_name = models.CharField(max_length=100)
    code = models.CharField(max_length=20)
    image = models.ImageField(upload_to='img/23/',null=True, blank=True)

    def __str__(self):
        return f"{self.leadername} - {self.foundation_name}"

class Votedatas(models.Model):
    leadername = models.CharField(max_length=100)
    total_votes = models.CharField(max_length=20)

    def __str__(self):
        return f"{self.leadername} - {self.total_votes}"