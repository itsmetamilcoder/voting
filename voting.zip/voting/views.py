# views.py in your app (myapp/views.py)

from django.shortcuts import render
from .models import Voter

def home_page(request):
    return render(request, 'web/index.html')

def login_page(request):
    return render(request, 'web/login.html')

def reg_page(request):
    return render(request, 'web/reg.html')

def aadhaar_page(request):
    return render(request, 'web/aadhaar.html')

def aadhaar1_page(request):
    return render(request, 'web/aadhaar_next.html')

def logout_page(request):
    return render(request, 'web/index.html')

def voters_page(request):
    data = Voter.objects.all()
    return render(request, 'web/voters.html',{'voters_list': data})

def adminpage_page(request):
    return render(request, 'web/adminpanel.html')

def view_chain_page(request):
    data = Voter.objects.all()
    return render(request, 'web/view_chain.html', {'blocks': data})

def voterlist_page(request):
    return render(request, 'web/voterlist.html')

def voter_details_page(request):
    data = Voter.objects.all()
    return render(request, 'web/voter_details.html', {'voter': data})

