# admin.py in your app

from django.contrib import admin
from .models import Voter
from .models import Votedatas

admin.site.register(Voter)
admin.site.register(Votedatas)
